export default function Admin() {
  return (
    <main style={{ padding: 20 }}>
      <h1>Panel de Administración CBJTOP</h1>
      <p>Wallet: 0x7e8D70519359a13a32A6c2947CB7B70C3a7B4097</p>
      <p>Correo admin: lazarojaviergs@gmail.com</p>
      <p>Aquí podrás gestionar las inversiones de los usuarios.</p>
    </main>
  );
}
