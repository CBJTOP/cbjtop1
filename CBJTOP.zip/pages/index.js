export default function Home() {
  return (
    <main style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Bienvenido a CBJTOP</h1>
      <p>Invierte con confianza. Sistema seguro y moderno.</p>
      <a href="/login">Entrar</a>
    </main>
  );
}
