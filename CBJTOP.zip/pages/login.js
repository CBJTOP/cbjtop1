import { useState } from 'react';

export default function Login() {
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');

  const handleLogin = () => {
    if (user === 'cbjadmim' && pass === 'tupass') {
      window.location.href = '/admin';
    } else {
      alert('Datos incorrectos');
    }
  };

  return (
    <main style={{ padding: 20 }}>
      <h2>Iniciar sesión</h2>
      <input placeholder="Usuario" onChange={(e) => setUser(e.target.value)} />
      <input type="password" placeholder="Contraseña" onChange={(e) => setPass(e.target.value)} />
      <button onClick={handleLogin}>Entrar</button>
    </main>
  );
}
